from dataclasses import dataclass, field
from typing import List, Dict

@dataclass
class ConversationMemory:
    max_turns: int = 6
    messages: List[Dict[str, str]] = field(default_factory=list)

    def add(self, role: str, content: str) -> None:
        self.messages.append({"role": role, "content": content})
        # keep only last N user+assistant turns plus system handled separately
        if len(self.messages) > self.max_turns * 2:
            self.messages = self.messages[-self.max_turns * 2:]

    def history(self) -> List[Dict[str, str]]:
        return list(self.messages)

    def clear(self) -> None:
        self.messages.clear()
