import re

BLOCK_PATTERNS = [
    r"how to make.*bomb", r"steal.*password", r"bypass.*login", r"make malware",
    r"harm (myself|someone)", r"kill (myself|someone)", r"jailbreak", r"ignore previous instructions"
]

def safety_check(user_text: str) -> tuple[bool, str]:
    text = user_text.lower()
    for pattern in BLOCK_PATTERNS:
        if re.search(pattern, text):
            return False, "I cannot help with harmful or unsafe instructions. I can help with safe alternatives, prevention, or learning concepts."
    return True, ""

SYSTEM_PROMPT = """You are a helpful AI personal assistant.
Follow these rules:
- Be concise, polite, and practical.
- Ask a clarifying question only when truly needed.
- Do not invent facts. If unsure, say you are unsure.
- Refuse unsafe, hateful, discriminatory, or illegal requests.
- Avoid stereotypes and biased assumptions.
"""
