# Dual AI Personal Assistant: OSS vs Frontier Model

This project builds and evaluates two AI personal assistants with the same interface and features:

1. **Open Source Assistant** using `Qwen/Qwen2.5-0.5B-Instruct` from Hugging Face.
2. **Frontier Assistant** using a hosted OpenAI-compatible model such as `gpt-4.1-mini`.

The app supports multi-turn chat, short-term memory, basic assistant behavior, simple tool use, and safety guardrails.

## Features

- Streamlit chat interface
- OSS Hugging Face model wrapper
- Frontier API wrapper
- Short-term conversation memory
- Basic calculator tool using `calc:` command
- Lightweight guardrails for unsafe requests
- Custom evaluation framework for hallucination, bias, and safety
- Report template and infographic generator

## Architecture

```text
User -> Streamlit UI -> Assistant Router
                         |-> OSSAssistant -> Hugging Face Transformers
                         |-> FrontierAssistant -> Hosted API
                         |-> Memory Manager
                         |-> Guardrails
                         |-> Calculator Tool
```

## Setup

```bash
git clone <your-repo-url>
cd ai_personal_assistant_project
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env`:

```bash
OPENAI_API_KEY=your_api_key
FRONTIER_MODEL=gpt-4.1-mini
OSS_MODEL=Qwen/Qwen2.5-0.5B-Instruct
```

## Run the app

```bash
streamlit run app/streamlit_app.py
```

## Run evaluation

Frontier only:

```bash
EVAL_TARGET=frontier python evals/evaluate.py
python evals/make_infographic.py
```

OSS only:

```bash
EVAL_TARGET=oss python evals/evaluate.py
python evals/make_infographic.py
```

Both:

```bash
EVAL_TARGET=both python evals/evaluate.py
python evals/make_infographic.py
```

## Evaluation Method

The evaluation uses custom prompts across three categories:

- **Hallucination Rate:** checks whether the model invents false facts or fake citations.
- **Bias & Harmful Outputs:** checks stereotypes and discriminatory assumptions.
- **Content Safety:** checks refusal behavior for jailbreak and harmful prompts.

A lightweight rule-based judge flags risky responses. In a production version, this can be replaced with LLM-as-judge plus human review.

## Tradeoffs

- Qwen2.5-0.5B is cheap and deployable on Hugging Face Spaces, but it is weaker than frontier models on reasoning and safety.
- Frontier models produce better answers and stronger refusal behavior, but they need API keys and have usage cost.
- Rule-based evals are simple and transparent, but less accurate than human review.
- Local OSS inference may be slow on CPU.

## What I would improve with more time

- Add retrieval augmented generation for factual grounding.
- Add persistent memory with SQLite or vector database.
- Add LangSmith, OpenTelemetry, or Phoenix observability.
- Add moderation API or Llama Guard for stronger safety.
- Deploy OSS model to Hugging Face Spaces with GPU.
- Add more benchmark prompts and human review.

## Deployment: Hugging Face Spaces

1. Create a new Hugging Face Space.
2. Choose Streamlit.
3. Upload this repository.
4. Add `OPENAI_API_KEY` in Space secrets if using the frontier model.
5. Set `OSS_MODEL=Qwen/Qwen2.5-0.5B-Instruct`.
6. The public demo URL will be created automatically.

## Cost and Latency Table

| Deployment | Expected Cost | Expected Latency | Notes |
|---|---:|---:|---|
| Hugging Face Spaces CPU | Free tier possible | Slow, often 8-20s | Best for demo only |
| Hugging Face Spaces GPU | Paid | Faster, often 1-5s | Better user experience |
| Local Ollama | Free after hardware | Depends on laptop | Good for private testing |
| OpenAI API | Pay per token | Usually fast | Best quality baseline |

## Submission

Send:

- GitHub repository link
- Evaluation PDF
- Demo link if deployed

to: `work@ollive.ai`
