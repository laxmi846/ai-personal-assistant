import os
import streamlit as st
from dotenv import load_dotenv
from app.memory import ConversationMemory
from app.oss_assistant import OSSAssistant
from app.frontier_assistant import FrontierAssistant
from app.tools import calculator

load_dotenv()
st.set_page_config(page_title="Dual AI Personal Assistant", page_icon="🤖")
st.title("Dual AI Personal Assistant")
st.caption("Compare an open-source Hugging Face assistant with a hosted frontier model assistant.")

if "memory" not in st.session_state:
    st.session_state.memory = ConversationMemory(max_turns=int(os.getenv("MAX_HISTORY_TURNS", "6")))
if "chat" not in st.session_state:
    st.session_state.chat = []

mode = st.sidebar.selectbox("Assistant", ["Open Source - Qwen2.5", "Frontier - OpenAI"])
st.sidebar.info("Use calculator: type `calc: 12*8+4`")
if st.sidebar.button("Clear memory"):
    st.session_state.memory.clear()
    st.session_state.chat = []
    st.rerun()

for role, content in st.session_state.chat:
    with st.chat_message(role):
        st.write(content)

prompt = st.chat_input("Ask your assistant...")
if prompt:
    st.session_state.chat.append(("user", prompt))
    with st.chat_message("user"):
        st.write(prompt)

    try:
        if prompt.lower().startswith("calc:"):
            answer = f"Answer: {calculator(prompt[5:].strip())}"
        elif mode.startswith("Open Source"):
            if "oss_bot" not in st.session_state:
                st.session_state.oss_bot = OSSAssistant()
            answer = st.session_state.oss_bot.reply(prompt, st.session_state.memory.history())
        else:
            if "frontier_bot" not in st.session_state:
                st.session_state.frontier_bot = FrontierAssistant()
            answer = st.session_state.frontier_bot.reply(prompt, st.session_state.memory.history())
    except Exception as e:
        answer = f"Error: {e}"

    st.session_state.memory.add("user", prompt)
    st.session_state.memory.add("assistant", answer)
    st.session_state.chat.append(("assistant", answer))
    with st.chat_message("assistant"):
        st.write(answer)
