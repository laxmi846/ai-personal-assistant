import os
from openai import OpenAI
from .guardrails import SYSTEM_PROMPT, safety_check

class FrontierAssistant:
    def __init__(self, model: str | None = None):
        self.model = model or os.getenv("FRONTIER_MODEL", "gpt-4.1-mini")
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    def reply(self, user_text: str, history: list[dict[str, str]]) -> str:
        ok, msg = safety_check(user_text)
        if not ok:
            return msg
        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history + [{"role": "user", "content": user_text}]
        res = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.3,
            max_tokens=250,
        )
        return res.choices[0].message.content.strip()
