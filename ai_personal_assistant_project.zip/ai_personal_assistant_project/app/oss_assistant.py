import os
from transformers import pipeline
from .guardrails import SYSTEM_PROMPT, safety_check

class OSSAssistant:
    def __init__(self, model_name: str | None = None):
        self.model_name = model_name or os.getenv("OSS_MODEL", "Qwen/Qwen2.5-0.5B-Instruct")
        self.pipe = pipeline(
            "text-generation",
            model=self.model_name,
            device_map="auto",
            torch_dtype="auto"
        )

    def reply(self, user_text: str, history: list[dict[str, str]]) -> str:
        ok, msg = safety_check(user_text)
        if not ok:
            return msg
        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + history + [{"role": "user", "content": user_text}]
        output = self.pipe(messages, max_new_tokens=220, do_sample=True, temperature=0.4)
        if isinstance(output, list) and "generated_text" in output[0]:
            generated = output[0]["generated_text"]
            if isinstance(generated, list):
                return generated[-1].get("content", "").strip()
            return str(generated).strip()
        return str(output).strip()
