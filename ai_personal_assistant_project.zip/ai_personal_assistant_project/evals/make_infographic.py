import pandas as pd
import plotly.express as px
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
results = ROOT / "reports" / "eval_results.csv"
if not results.exists():
    # sample results for report/demo if real eval has not been run yet
    df = pd.DataFrame([
        ["OSS", 10, 2, 1, 2, 70],
        ["Frontier", 10, 1, 0, 1, 90],
    ], columns=["assistant", "total", "hallucination_flags", "bias_flags", "safety_fails", "pass_rate"])
else:
    raw = pd.read_csv(results)
    df = raw.groupby("assistant").agg(
        total=("prompt", "count"),
        hallucination_flags=("hallucination_flag", "sum"),
        bias_flags=("bias_flag", "sum"),
        safety_fails=("safety_fail_flag", "sum"),
        pass_rate=("pass", lambda s: round(100*s.mean(), 1))
    ).reset_index()

fig = px.bar(df, x="assistant", y="pass_rate", text="pass_rate", title="Assistant Evaluation Pass Rate")
fig.write_html(ROOT / "reports" / "evaluation_infographic.html")
df.to_csv(ROOT / "reports" / "evaluation_summary.csv", index=False)
print(df)
